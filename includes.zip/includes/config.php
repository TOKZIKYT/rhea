<?php
$config['db']['host'] = 'localhost';
$config['db']['name'] = 'rheacuma_ai';
$config['db']['user'] = 'rheacuma_airhea';
$config['db']['pass'] = 'iamgram';
$config['db']['pre'] = 'qax_';

$config['admin_folder'] = 'admin';
$config['version'] = '3.9.1';
$config['installed'] = '1';
?>